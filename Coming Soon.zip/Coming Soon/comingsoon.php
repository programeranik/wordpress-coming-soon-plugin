<?php
/**
 * Plugin Name: Coming Soon by Qubiqsoft
 * Description: A simple coming soon plugin with live/development mode.
 * Version: 1.0.0
 * Author: Md Anik Hossen
 * Author URI: https://qubiqsoft.com
 */

if (!defined('ABSPATH')) {
    exit;
}

class Qubiqsoft_Coming_Soon {
    public function __construct() {
        add_action('admin_menu', array($this, 'create_admin_menu'));
        add_action('template_redirect', array($this, 'display_coming_soon'));
    }

    public function create_admin_menu() {
        add_menu_page('Coming Soon Settings', 'Coming Soon', 'manage_options', 'qubiqsoft-coming-soon', array($this, 'admin_settings_page'));
    }

    public function admin_settings_page() {
        if (isset($_POST['qubiqsoft_mode'])) {
            update_option('qubiqsoft_coming_soon_mode', sanitize_text_field($_POST['qubiqsoft_mode']));
        }
        $mode = get_option('qubiqsoft_coming_soon_mode', 'development');
        ?>
        <div class="wrap">
            <h1>Coming Soon Settings</h1>
            <form method="post">
                <label>
                    <input type="radio" name="qubiqsoft_mode" value="live" <?php checked($mode, 'live'); ?>> Live
                </label>
                <label>
                    <input type="radio" name="qubiqsoft_mode" value="development" <?php checked($mode, 'development'); ?>> Development
                </label>
                <br><br>
                <input type="submit" class="button button-primary" value="Save Settings">
            </form>
        </div>
        <?php
    }

    public function display_coming_soon() {
        if (get_option('qubiqsoft_coming_soon_mode', 'development') === 'development' && !current_user_can('manage_options')) {
            wp_die('<h1 style="text-align:center; font-size:50px; padding-top:100px;">🚀 Coming Soon 🚀</h1><p style="text-align:center; font-size:20px;">Our website is under construction. Stay tuned!</p>', 'Coming Soon');
        }
    }
}

new Qubiqsoft_Coming_Soon();
